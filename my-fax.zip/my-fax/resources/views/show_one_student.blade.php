@extends('layouts.app')
@section("title",'Edit Student')
@section('content')

    <div class='container'>
        <h1 class="text-center">Edit Studenet</h1>
        <br/>
        <form action='/update' method="post" class="form-group" style="width=70%; margin-left=15%" >
            <input type="hidden" name="_token" value="<?php echo csrf_token()?>">
            <input type="hidden" name= "_token" value="<?php echo csrf_token()?>">
            <input type="hidden"  value='{{$user->id}}' name='id' >
            <label class="form-group" >First Name</label>
            <input type="text" class="form-control" value='{{$user->first_name}}' name="first_name" pattern="[A-Za-z]+[a-zA-Z\s]+[A-Za-z]+" title="The name must start with alfabet and must end with alfabet">
            <label class="form-group">Last Name </label>
            <input type="text" class="form-control" value='{{$user->last_name}}' name="last_name"pattern="[A-Za-z]+[a-zA-Z\s]+[A-Za-z]+" title="The name must start with alfabet and must end with alfabet" >
            <label>City Name</label>
            <input type="text" class="form-control" value='{{$user->city_name}}' name="city_name" pattern="[A-Za-z]+[a-zA-Z\s]+[A-Za-z]+" title="The name must start with alfabet and must end with alfabet">
            <label class="form-group">Email</label> 
            <input type="text" class="form-control" value='{{$user->email}}' name="email"><br>
            <button type="submit" value="Change student" class="btn btn-primary">Update</button>


        </form>
        <br>
    </div>

@endsection
