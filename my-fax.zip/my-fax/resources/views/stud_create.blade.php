@extends('layouts.app')
@section("title",'Student Add')
@section('content')
    <div class="container">
        <h2 class="text-center">Student Add</h2>
        <br/>
        <form action='/create' method="post" class="form-group" style="width=70%; margin-left=15%" action='/show-student'>
            <input type="hidden" name="_token" value="<?php echo csrf_token()?>">
            <input type="hidden" name= "_token" value="<?php echo csrf_token()?>">
            <label class="form-group" >First Name</label>
            <input type="text" class="form-control" placeholder="First Name" name="first_name" pattern="[A-Za-z]+[a-zA-Z\s]+[A-Za-z]+" title="The name must start with alfabet and must end with alfabet">
            <label class="form-group">Last Name </label>
            <input type="text" class="form-control" placeholder="Last Name" name="last_name"pattern="[A-Za-z]+[a-zA-Z\s]+[A-Za-z]+" title="The name must start with alfabet and must end with alfabet" >
            <label>City Name</label>
            <select class="form-control" name="city_name">
                <option value="bhubaneswar">Bhubaneswar</option>
                <option value="cuttak">Cuttak</option>
            </select>
            <label class="form-group">Email</label> 
            <input type="text" class="form-control" placeholder="Enter Email" name="email"><br>
            <button type="submit" value="Add Student" class="btn btn-primary">Submit</button>


        </form>
        <br>
                <a href="/show-student" class="btn btn-outline-primary">Show Student</a>
    </div>
@endsection