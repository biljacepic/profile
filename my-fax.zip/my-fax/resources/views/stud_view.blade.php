@extends('layouts.app')
@section("title",'View Students')
@section('content')
    <div class='container'>
        <h1 class="text-center">View Students</h1>
        <table class=" table table-bordered table-striped">
            <thead>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>City Name</th>
                <th>Email</th>
                <th>Action</th>
            </thead>
            <tbody>
                @foreach($users as $user)
                    <tr>
                        <td>{{$user->id}}</td>
                        <td>{{$user->first_name}}</td>
                        <td>{{$user->last_name}}</td>
                        <td>{{$user->city_name}}</td>
                        <td>{{$user->email}}</td>
                        <td><a href="/delete/student/{{$user->id}}" class="btn btn-outline-danger btn-sm " >Delete</a>
                            <a href="/edit/student/{{$user->id}}" class="btn btn-outline-primary btn-sm " >Edit</a></td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <br>
        <a href="/insert" class="btn btn-outline-primary">Add New Students</a>
    </div>
    
@endsection