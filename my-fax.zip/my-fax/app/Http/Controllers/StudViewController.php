<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Schema;


class StudViewController extends Controller{
    public function index(){
        if(!Schema::hasTable('student_details')){
            echo "<script> alert('Table not exists,first you have to create table')</script";
            return redirect('/'); 
        }else{
            $users=DB::select('select * from student_details');
            if (count($users)>0){
                return view('stud_view',['users'=>$users]);
            }else{
                echo '<script> alert("There no students recorded in table,you hava to add students in table")</script>';
                return redirect('insert');
            }                                                                                                                                                                      
        }    
    }
    public function editByid($id){
        $user=DB::select('select * from student_details where id='.$id);

        //echo $user[0]->first_name;
        return view('show_one_student',["user"=>$user[0]]);
    }
    public function change(Request $request){
        $rules=[
            'first_name'=>'required|string|min:3|max:255',
            'last_name'=>'required|string|min:3|max:255',
            'city_name'=>'required|string|min:3|max:255',
            'email'=>'required|email|max:255'
        ];
        $validator=Validator::make($request->all(),$rules);
        if($validator->fails()){
            return redirect('insert')->withInput()->withErrors($validator);
        }else{ 
            try{
                $id=$request->input('id');
                $first_name=$request->input('first_name');
                $last_name=$request->input('last_name');
                $city_name=$request->input('city_name');
                $email=$request->input('email');
                // $data=array('first_name'=>$first_name,"last_name"=>$last_name,"city_name"=>$city_name,"email"=>$email);
                //echo $data;
                //DB::table('student_details')->update($data);
                DB::update('update student_details set first_name = ?,last_name=?,city_name=?,email=? where id = ?',[$first_name,$last_name,$city_name,$email,$id]);
                echo '<script> alert("Updated sudent successfully")</script>';
                //$users=DB::select('select * from student_details');
                //return view('stud_view',['users'=>$users]);
                return $this->index();
            }
            catch(Exeption $e){
                return redirect('insert')->with('faild','operation faild');
            }
        }    
    }
}