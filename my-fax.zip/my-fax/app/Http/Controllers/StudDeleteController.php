<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\Controllers\StudViewController;

class StudDeleteController extends Controller{
    public function destroy($id){
        DB::delete('delete from student_details where id='.$id);
        //$users=DB::select('select * from student_details');
        //return view('stud_view',['users'=>$users]);
        return StudViewController::index();
    }

}