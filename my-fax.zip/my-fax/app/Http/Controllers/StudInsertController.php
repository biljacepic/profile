<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Schema;

class StudInsertController extends Controller
{
    public function insertform(){

        return view('stud_create');

    }
    public function insert(Request $request){
        $rules=[
            'first_name'=>'required|string|min:3|max:255',
            'last_name'=>'required|string|min:3|max:255',
            'city_name'=>'required|string|min:3|max:255',
            'email'=>'required|email|max:255'
        ];
        $validator=Validator::make($request->all(),$rules);
        if($validator->fails()){
            return redirect('insert')->withInput()->withErrors($validator);
        }else{
            if(!Schema::hasTable('student_details')){
                echo "<script> alert('Table not exists,first you have to create table')</script>";
                return redirect('welcome'); 
             }else{ 
                try{   
                    $first_name=$request->input('first_name');
                    $last_name=$request->input('last_name');
                    $city_name=$request->input('city_name');
                    $email=$request->input('email');
                    $data=array("first_name"=>$first_name,"last_name"=>$last_name,"city_name"=>$city_name,"email"=>$email);
                    DB::table('student_details')->insert($data);
                    echo "<script> alert('Record inserted successfully')</script>";
                    //echo "<a href='/insert'> Click here</a> go to back.";
                    return redirect('insert')->with('status','Insert successfully');
                }
                catch(Exeption $e){
                    return redirect('insert')->with('faild','operation faild');
                }
             }
        }
    }

}