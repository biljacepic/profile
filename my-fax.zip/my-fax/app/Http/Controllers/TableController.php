<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;

class TableController extends Controller
{
    public function createTable($table_name,$fields=[]){
        if(!Schema::hasTable($table_name)){
            Schema::create($table_name,function(Blueprint $table)use($fields,$table_name){
                $table->increments('id');
                if(count($fields)>0){
                    foreach($fields as $field){
                        $table->{$field['type']}($field['name']);
                    }
                }
                $table->timestamp('created_at')->useCurrent();
                $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
            });
            echo '<script> alert("Given table has been successfully created")</script>';
            return view('welcome');
        }
        echo '<script> alert("Given table already exists")</script>';
        return view('welcome');
    }

    public function operate(){
        $table_name='student_details';
        $fields=[
            ['name'=>'first_name','type'=>'string'],
            ['name'=>'last_name','type'=>'string'],
            ['name'=>'city_name','type'=>'string'],
            ['name'=>'email','type'=>'string'],
        ];
        return $this->createTable($table_name,$fields);

    }

    public function removeTable($table_name){
        Schema::dropIfExists($table_name);
        return true;
    }
}
