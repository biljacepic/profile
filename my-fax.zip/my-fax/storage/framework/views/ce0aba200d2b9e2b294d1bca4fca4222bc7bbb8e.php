<?php $__env->startSection("title",'Start Project'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="text-center">Create Base  First</h1><br><br>
        <div class="container" style="text-align: center">
            <p class='text-center'> First you have to create database name: fax  then create table</p>
         
        <h2>Create Table</h2><br>
        <a href="/create-table" class="btn btn-outline-primary">Create Table When You First Start Project</a>
            <br><br>
        <h2 class="text-center">Student Add</h2><br>
        <p class='text-center'>When you create table then you can add students</p>
        <br/>
        <a href="/insert" class="btn btn-outline-primary">Add Students</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my-fax\resources\views/welcome.blade.php ENDPATH**/ ?>