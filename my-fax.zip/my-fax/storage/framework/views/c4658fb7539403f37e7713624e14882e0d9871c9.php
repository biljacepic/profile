
<?php $__env->startSection("title",'Edit Student'); ?>
<?php $__env->startSection('content'); ?>

    <div class='container'>
        <h1 class="text-center">Edit Studenet</h1>
        <br/>
        <form action='/update' method="post" class="form-group" style="width=70%; margin-left=15%" >
            <input type="hidden" name="_token" value="<?php echo csrf_token()?>">
            <input type="hidden" name= "_token" value="<?php echo csrf_token()?>">
            <input type="hidden"  value='<?php echo e($user->id); ?>' name='id' >
            <label class="form-group" >First Name</label>
            <input type="text" class="form-control" value='<?php echo e($user->first_name); ?>' name="first_name" pattern="[A-Za-z]+[a-zA-Z\s]+[A-Za-z]+" title="The name must start with alfabet and must end with alfabet">
            <label class="form-group">Last Name </label>
            <input type="text" class="form-control" value='<?php echo e($user->last_name); ?>' name="last_name"pattern="[A-Za-z]+[a-zA-Z\s]+[A-Za-z]+" title="The name must start with alfabet and must end with alfabet" >
            <label>City Name</label>
            <input type="text" class="form-control" value='<?php echo e($user->city_name); ?>' name="city_name" pattern="[A-Za-z]+[a-zA-Z\s]+[A-Za-z]+" title="The name must start with alfabet and must end with alfabet">
            <label class="form-group">Email</label> 
            <input type="text" class="form-control" value='<?php echo e($user->email); ?>' name="email"><br>
            <button type="submit" value="Change student" class="btn btn-primary">Update</button>


        </form>
        <br>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my-fax\resources\views/show_one_student.blade.php ENDPATH**/ ?>