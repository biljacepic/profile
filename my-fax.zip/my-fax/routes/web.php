<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get("insert", "\App\Http\Controllers\StudInsertController@insertform");
Route::post("create","\App\Http\Controllers\StudInsertController@insert");
Route::get("view-record","\App\Http\Controllers\StudViewController@index");
Route::get("show-student","\App\Http\Controllers\StudViewController@index");
Route::get("delete/student/{id}","\App\Http\Controllers\StudDeleteController@destroy");
Route::get("edit/student/{id}","\App\Http\Controllers\StudViewController@editByid");
Route::post("update","\App\Http\Controllers\StudViewController@change");
Route::get("/create-table","\App\Http\Controllers\TableController@operate");
